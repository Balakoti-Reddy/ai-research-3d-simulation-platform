import unittest
from unittest.mock import patch
from src.layer3_research.research_engine import (
    ResearchSimulationEngine,
    ResearchDiscoveryEngine,
    ResearchSource,
)

ARXIV_XML = b'''<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <entry>
    <id>https://arxiv.org/abs/2401.12345</id>
    <title>Flood prediction using rainfall and terrain data</title>
    <summary>A flood prediction method combines rainfall observations and terrain elevation data.</summary>
    <published>2024-01-01T00:00:00Z</published>
    <author><name>Example Author</name></author>
  </entry>
  <entry>
    <id>https://arxiv.org/abs/2401.54321</id>
    <title>Quantum chromodynamics and particle physics</title>
    <summary>A study of particle interactions in high energy physics.</summary>
    <published>2024-01-01T00:00:00Z</published>
    <author><name>Unrelated Author</name></author>
  </entry>
</feed>'''


class FakeResponse:
    def __init__(self, data):
        self.data = data
    def __enter__(self):
        return self
    def __exit__(self, *args):
        return False
    def read(self):
        return self.data


class TestLayer3ResearchEngine(unittest.TestCase):
    def setUp(self):
        self.engine = ResearchSimulationEngine()

    def test_failed_search_returns_no_fabricated_sources(self):
        discovery = ResearchDiscoveryEngine(opener=lambda *a, **k: (_ for _ in ()).throw(OSError("offline")))
        self.assertEqual(discovery.search("flood prediction"), [])
        self.assertEqual(discovery.last_search_status, "FAILED")
        self.assertIn("unavailable", discovery.last_search_error.lower())

    def test_search_filters_irrelevant_results_and_parses_real_metadata(self):
        discovery = ResearchDiscoveryEngine(opener=lambda *a, **k: FakeResponse(ARXIV_XML))
        sources = discovery.search("flood prediction rainfall terrain")
        self.assertEqual(len(sources), 1)
        self.assertIn("Flood prediction", sources[0].title)
        self.assertEqual(sources[0].authors_or_org, "Example Author")
        self.assertEqual(sources[0].url, "https://arxiv.org/abs/2401.12345")
        self.assertGreaterEqual(sources[0].relevance_score, 0.20)
        self.assertEqual(discovery.last_search_status, "SUCCEEDED")

    def test_no_sources_does_not_claim_evidence_is_supported(self):
        result = self.engine.process_action("RESEARCH", "flood prediction system")
        # This environment may not have network access; both outcomes must be truthful.
        self.assertIn(result.status, {"FAILED", "NO_RESULTS", "SUCCEEDED"})
        if not result.sources:
            self.assertTrue(all(f.evidence_status == "INSUFFICIENT_EVIDENCE" for f in result.findings))
        else:
            self.assertTrue(all(f.evidence_status == "NOT_YET_VERIFIED" for f in result.findings))

    def test_evidence_does_not_treat_first_source_as_proof(self):
        src = ResearchSource(
            title="Flood prediction using rainfall and terrain data",
            authors_or_org="Example Author",
            summary="A study about flood prediction.",
            url="https://arxiv.org/abs/2401.12345",
        )
        findings = self.engine.evidence.analyze([src], "flood prediction")
        self.assertEqual(findings[0].evidence_status, "NOT_YET_VERIFIED")
        self.assertIn(src.url, findings[0].supporting_sources)

    def test_method_evaluation_is_explicitly_preliminary(self):
        methods = self.engine.methods.evaluate("low-cost building thermal insulation")
        self.assertTrue(methods)
        self.assertIn("thermal", methods[0].method_name.lower())
        self.assertEqual(methods[0].compatibility_score, "Unverified")

    def test_registered_calculation_executes_and_validates_inputs(self):
        result = self.engine.process_action(
            "RUN_CALCULATION", "optical lens calculation",
            {"focal_length_mm": 50, "object_distance_mm": 200},
        )
        self.assertTrue(result.execution["attempted"])
        self.assertEqual(result.execution["status"], "SUCCEEDED")
        self.assertAlmostEqual(result.execution["outputs"][0]["image_distance_mm"], 66.6666667, places=5)

        invalid = self.engine.process_action(
            "RUN_CALCULATION", "optical lens calculation",
            {"focal_length_mm": 50, "object_distance_mm": 50},
        )
        self.assertEqual(invalid.status, "BLOCKED")

    def test_unregistered_simulation_never_reports_success(self):
        result = self.engine.process_action("RUN_SIMULATION", "simulate flood conditions", {})
        self.assertEqual(result.status, "UNSUPPORTED")
        self.assertNotEqual(result.execution["status"], "SUCCEEDED")
        self.assertFalse(result.visualization_data["available"])

    def test_unsupported_action_is_not_reported_as_success(self):
        result = self.engine.process_action("DO_MAGIC", "something", {})
        self.assertEqual(result.status, "UNSUPPORTED_ACTION")


if __name__ == "__main__":
    unittest.main()
