import uuid
import time
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

@dataclass
class Capability:
    capability_id: str
    description: str
    is_available: bool
    required_inputs: List[str] = field(default_factory=list)

@dataclass
class DecisionRecord:
    decision_id: str = field(default_factory=lambda: f"dec-{str(uuid.uuid4())[:8]}")
    project_id: str = "default-project"
    specification_version: int = 1
    current_state: str = "UNDERSTANDING"
    selected_action: str = "CLARIFY"
    action_parameters: Dict[str, Any] = field(default_factory=dict)
    reason: str = "Initial evaluation."
    missing_information: List[str] = field(default_factory=list)
    confidence: str = "Medium"
    requires_user_approval: bool = False
    status: str = "READY"
    question: Optional[str] = None
    prompt: Optional[str] = None
    created_at: float = field(default_factory=time.time)

class ResearchDecisionEngine:
    """Context-aware Research Decision Engine (Layer 2) with prioritized evaluation."""

    def __init__(self):
        self.capabilities = {
            "arxiv_retrieval": Capability("arxiv_retrieval", "Live arXiv academic search", True, ["query"]),
            "simulation_engine": Capability("simulation_engine", "3D physics and optical simulation", True, ["model_config"]),
            "calculation_tool": Capability("calculation_tool", "Parametric optical formulas", True, ["focal_length", "object_distance"]),
        }
        self.asked_questions: List[str] = []

    def evaluate_state_and_decide(self, spec: Any, execution_state: Optional[Dict[str, Any]] = None) -> DecisionRecord:
        execution_state = execution_state or {}
        spec_version = getattr(spec, "specification_version", 1)
        objective = getattr(spec, "objective", None)
        unresolved = getattr(spec, "unresolved_questions", [])

        record = DecisionRecord(specification_version=spec_version)

        # Priority 1: Unclear / Ambiguous Objective check
        if not objective or len(objective.strip()) < 5 or unresolved or any(v in objective.lower() for v in ["make it better", "something good", "do something"]):
            record.current_state = "CLARIFICATION_REQUIRED"
            record.selected_action = "CLARIFY"
            record.reason = "Research objective is unclear or ambiguous; clarification is required before proceeding."
            record.missing_information = unresolved or ["Specific research goals and target outcomes"]
            q = "Could you please clarify your specific research objective and what you would like to achieve?"
            record.question = q
            record.prompt = "Action: CLARIFY | State: CLARIFICATION_REQUIRED"
            record.status = "READY"
            return record

        lower_obj = objective.lower()

        # Priority 2: User Approval Required for Consequential Actions (e.g. heavy computation, training)
        if any(w in lower_obj for w in ["train", "deploy", "heavy computation", "execute large"]) and not execution_state.get("user_approved", False):
            record.current_state = "WAITING_FOR_USER"
            record.selected_action = "WAIT_FOR_USER"
            record.reason = "Proposed action involves consequential computation and requires user approval."
            record.requires_user_approval = True
            record.question = "Do you approve proceeding with this consequential action?"
            record.prompt = "Action: WAIT_FOR_USER | State: WAITING_FOR_USER"
            record.status = "AWAITING_APPROVAL"
            return record

        # Priority 3: Missing Data for Simulation / Execution Blockers
        if any(w in lower_obj for w in ["run", "execute simulation"]) and not execution_state.get("model_ready", False):
            record.current_state = "BLOCKED"
            record.selected_action = "REPORT_BLOCKER"
            record.reason = "Simulation requested but required model configuration or dataset is unavailable."
            record.missing_information = ["Validated simulation model", "Required input parameters"]
            record.question = "Cannot execute simulation yet: required model inputs or datasets are missing."
            record.prompt = "Action: REPORT_BLOCKER | State: BLOCKED"
            record.status = "BLOCKED"
            return record

        # Priority 4: Literature Exploration & Research
        if any(w in lower_obj for w in ["investigate", "explore", "methods", "predict", "find", "papers", "study", "building", "flood", "design", "model"]) or len(execution_state.get("sources", [])) == 0:
            record.current_state = "READY_FOR_RESEARCH"
            record.selected_action = "RESEARCH"
            record.action_parameters = {"query": objective}
            record.reason = "Research objective is clear and appropriate for initial literature and evidence retrieval."
            record.question = f"Would you like to proceed with retrieving existing papers and methodologies for: '{objective}'?"
            record.prompt = f"Action: RESEARCH | State: READY_FOR_RESEARCH"
            record.status = "READY"
            return record

        # Default fallback action
        record.current_state = "METHOD_EVALUATION"
        record.selected_action = "IDENTIFY_METHODS"
        record.reason = "Objective and sources evaluated; identifying candidate scientific methods."
        record.question = "Shall we evaluate suitable methods for this research?"
        record.prompt = "Action: IDENTIFY_METHODS | State: METHOD_EVALUATION"
        record.status = "READY"
        return record
