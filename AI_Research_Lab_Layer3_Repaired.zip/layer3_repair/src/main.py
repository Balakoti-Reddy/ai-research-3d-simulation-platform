import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi import FastAPI
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel
from typing import Optional

from src.layer1_understanding.extractor import PrimaryUnderstandingEngine
from src.layer2_decision.decision_engine import ResearchDecisionEngine
from src.layer3_research.research_engine import ResearchSimulationEngine
from src.layer4_workspace.simulation_controls import InteractiveWorkspace
from src.utils.notebook_db import init_db, save_project
from src.utils.report_generator import generate_markdown_report

app = FastAPI(title="AI Research Lab")

init_db()

understanding_engine = PrimaryUnderstandingEngine()
decision_engine = ResearchDecisionEngine()
research_engine = ResearchSimulationEngine()
workspace = InteractiveWorkspace()

class UserInput(BaseModel):
    message: str

class ParamInput(BaseModel):
    laser_power_pct: Optional[float] = None
    image_size_m: Optional[float] = None

@app.get("/", response_class=HTMLResponse)
async def read_root():
    with open("templates/index.html", "r", encoding="utf-8") as f:
        return f.read()

@app.post("/api/process")
async def process_user_input(payload: UserInput):
    # Layer 1 updates the research specification first.
    updated_spec = understanding_engine.parse_input(payload.message)

    # Layer 2 chooses the next action before Layer 3 performs work. This avoids
    # searching with an incomplete objective when clarification is required.
    decision = decision_engine.evaluate_state_and_decide(
        updated_spec,
        {"sources_retrieved": False, "sources": []},
    )
    sources = []
    research_status = "NOT_REQUESTED"
    research_error = None
    if decision.selected_action == "RESEARCH" and updated_spec.objective:
        sources = research_engine.search_knowledge_base(updated_spec.objective)
        research_status = research_engine.discovery.last_search_status
        research_error = research_engine.discovery.last_search_error

    sources_data = [
        {
            "title": s.title,
            "authors_or_org": s.authors_or_org,
            "summary": s.summary,
            "url": s.url,
            "components": getattr(s, "components", []),
            "source_type": s.source_type,
            "published": s.published,
            "relevance_score": s.relevance_score,
        } for s in sources
    ]
    app.state.last_sources_data = sources_data

    # Save only actual retrieved records; failed/empty searches remain empty.
    save_project(
        title=updated_spec.objective or "Research Project",
        spec={"objective": updated_spec.objective, "tools_detected": updated_spec.tools_detected},
        sources=sources_data,
        params=workspace.params.__dict__,
    )

    return {
        "spec": {
            "objective": updated_spec.objective,
            "tools_detected": updated_spec.tools_detected,
            "machinery_detected": updated_spec.machinery_detected,
        },
        "decision": {
            "question": decision.question,
            "prompt": decision.prompt,
            "selected_action": decision.selected_action,
            "current_state": decision.current_state,
            "reason": decision.reason,
        },
        "research": {"status": research_status, "error": research_error},
        "sources": sources_data,
    }

@app.post("/api/parameters")
async def update_sim_parameters(params: ParamInput):
    res = workspace.calculate_optical_field(params.dict(exclude_none=True))
    return res

@app.get("/api/export-report")
async def export_report():
    obj_title = understanding_engine.spec.objective or "Research Project"
    # Do not launch a fresh search during export and do not attach unrelated
    # optical metrics to a general research report. Metrics are empty until a
    # relevant, recorded execution result exists.
    sources_data = getattr(app.state, "last_sources_data", [])
    filepath = generate_markdown_report(
        obj_title,
        {"objective": obj_title, "tools": understanding_engine.spec.tools_detected},
        sources_data,
        {},
    )
    return FileResponse(filepath, filename=os.path.basename(filepath), media_type="text/markdown")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
