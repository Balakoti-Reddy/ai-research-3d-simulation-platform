"""Research discovery and execution primitives for AI Research Lab.

Important: this module never fabricates a source or reports a simulation as
successful unless a registered handler actually performs the requested work.
"""
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple

ARXIV_API = "https://export.arxiv.org/api/query"
ATOM_NS = {"atom": "http://www.w3.org/2005/Atom"}


@dataclass
class ResearchSource:
    title: str
    authors_or_org: str
    summary: str
    url: str
    components: List[str] = field(default_factory=list)
    source_type: str = "academic_paper"
    source_id: str = ""
    published: str = ""
    relevance_score: float = 0.0


@dataclass
class EvidenceItem:
    finding_id: str
    claim: str
    supporting_sources: List[str]
    evidence_status: str  # INSUFFICIENT_EVIDENCE unless a claim is actually checked
    confidence: str
    limitations: List[str] = field(default_factory=list)
    conflicting_evidence: List[str] = field(default_factory=list)


@dataclass
class MethodEvaluation:
    method_name: str
    purpose: str
    required_inputs: List[str]
    expected_outputs: List[str]
    limitations: List[str]
    compatibility_score: str


@dataclass
class Layer3Result:
    task_id: str
    project_id: str
    action_type: str
    status: str
    summary: str
    findings: List[EvidenceItem] = field(default_factory=list)
    sources: List[ResearchSource] = field(default_factory=list)
    methods: List[MethodEvaluation] = field(default_factory=list)
    execution: Dict[str, Any] = field(default_factory=dict)
    visualization_data: Dict[str, Any] = field(default_factory=dict)
    limitations: List[str] = field(default_factory=list)
    uncertainties: List[str] = field(default_factory=list)
    blockers: List[str] = field(default_factory=list)
    recommended_next_actions: List[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)


class ResearchDiscoveryEngine:
    """Retrieve actual arXiv records, validate them, and rank by relevance."""

    STOP_WORDS = {
        "a", "an", "and", "are", "as", "at", "be", "by", "for", "from",
        "how", "i", "in", "is", "it", "of", "on", "or", "our", "system",
        "the", "this", "to", "using", "with", "would", "like", "want", "we",
        "build", "create", "develop", "make", "design", "low", "cost",
    }

    def __init__(self, timeout: float = 8.0, opener=None):
        self.timeout = timeout
        self.opener = opener or urllib.request.urlopen
        self.last_search_status = "NOT_STARTED"
        self.last_search_error: Optional[str] = None

    @classmethod
    def _terms(cls, text: str) -> set:
        return {
            token.lower() for token in re.findall(r"[A-Za-z][A-Za-z0-9-]{2,}", text or "")
            if token.lower() not in cls.STOP_WORDS
        }

    def _build_query(self, query: str) -> str:
        terms = sorted(self._terms(query))
        if not terms:
            return ""
        # Use a modest set of meaningful terms rather than URL-encoding a whole
        # paragraph as one arXiv search term.
        return " AND ".join(f'all:"{term}"' for term in terms[:8])

    def search(self, query: str, max_results: int = 5) -> List[ResearchSource]:
        self.last_search_status = "FAILED"
        self.last_search_error = None
        query = (query or "").strip()
        if not query:
            self.last_search_status = "INVALID_QUERY"
            self.last_search_error = "A non-empty research query is required."
            return []

        search_query = self._build_query(query)
        if not search_query:
            self.last_search_status = "INVALID_QUERY"
            self.last_search_error = "The query did not contain searchable terms."
            return []

        params = urllib.parse.urlencode({
            "search_query": search_query,
            "start": 0,
            "max_results": max(1, min(int(max_results), 20)),
            "sortBy": "relevance",
            "sortOrder": "descending",
        })
        request = urllib.request.Request(
            f"{ARXIV_API}?{params}",
            headers={"User-Agent": "AI-Research-Lab/1.0 (research discovery; contact: local app)"},
        )
        try:
            with self.opener(request, timeout=self.timeout) as response:
                xml_data = response.read()
            sources = self._parse_arxiv_xml(xml_data)
            terms = self._terms(query)
            for source in sources:
                source.relevance_score = self._relevance(source, terms)
            # Do not present unrelated results as relevant. This threshold is a
            # transparent lexical filter, not a claim of semantic verification.
            relevant = [s for s in sources if s.relevance_score >= 0.20]
            deduped: Dict[str, ResearchSource] = {}
            for source in relevant:
                key = source.source_id or source.url or source.title.casefold()
                deduped.setdefault(key, source)
            ranked = sorted(deduped.values(), key=lambda s: s.relevance_score, reverse=True)
            self.last_search_status = "SUCCEEDED" if ranked else "NO_RELEVANT_RESULTS"
            if not ranked:
                self.last_search_error = "The search completed, but no retrieved records passed the relevance filter."
            return ranked[:max(1, min(int(max_results), 20))]
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            self.last_search_status = "FAILED"
            self.last_search_error = f"Research provider unavailable: {type(exc).__name__}."
            return []
        except (ET.ParseError, ValueError, TypeError) as exc:
            self.last_search_status = "FAILED"
            self.last_search_error = f"Research provider returned invalid data: {type(exc).__name__}."
            return []

    @classmethod
    def _relevance(cls, source: ResearchSource, terms: set) -> float:
        if not terms:
            return 0.0
        title_terms = cls._terms(source.title)
        abstract_terms = cls._terms(source.summary)
        # Title matches count more than abstract matches.
        score = (2.0 * len(terms & title_terms) + len(terms & abstract_terms)) / (3.0 * len(terms))
        return round(min(score, 1.0), 3)

    def _parse_arxiv_xml(self, xml_data: bytes) -> List[ResearchSource]:
        root = ET.fromstring(xml_data)
        sources: List[ResearchSource] = []
        for entry in root.findall("atom:entry", ATOM_NS):
            title_node = entry.find("atom:title", ATOM_NS)
            summary_node = entry.find("atom:summary", ATOM_NS)
            id_node = entry.find("atom:id", ATOM_NS)
            if title_node is None or summary_node is None or id_node is None:
                continue
            title = " ".join((title_node.text or "").split())
            summary = " ".join((summary_node.text or "").split())
            url = (id_node.text or "").strip()
            if not title or not summary or not self._valid_arxiv_url(url):
                continue
            authors = []
            for author in entry.findall("atom:author", ATOM_NS):
                name = author.find("atom:name", ATOM_NS)
                if name is not None and (name.text or "").strip():
                    authors.append(name.text.strip())
            published_node = entry.find("atom:published", ATOM_NS)
            sources.append(ResearchSource(
                title=title,
                authors_or_org=", ".join(authors) if authors else "Author not listed",
                summary=summary,
                url=url,
                components=[],
                source_type="academic_paper",
                source_id=url.rstrip("/").split("/")[-1],
                published=(published_node.text or "").strip() if published_node is not None else "",
            ))
        return sources

    @staticmethod
    def _valid_arxiv_url(url: str) -> bool:
        parsed = urllib.parse.urlparse(url)
        return parsed.scheme == "https" and parsed.hostname in {"arxiv.org", "export.arxiv.org"} and "/abs/" in parsed.path


class EvidenceAnalysisEngine:
    """Report what sources were found without pretending they prove a claim."""

    def analyze(self, sources: List[ResearchSource], objective: str) -> List[EvidenceItem]:
        if not sources:
            return [EvidenceItem(
                finding_id="find-1",
                claim=f"Available retrieved sources are insufficient to assess: {objective}",
                supporting_sources=[],
                evidence_status="INSUFFICIENT_EVIDENCE",
                confidence="Low",
                limitations=["No relevant, validated research sources were retrieved."],
            )]
        return [EvidenceItem(
            finding_id=f"find-{idx + 1}",
            claim=f"Retrieved source relevant to the research topic: {src.title}",
            supporting_sources=[src.url],
            evidence_status="NOT_YET_VERIFIED",
            confidence="Low",
            limitations=[
                "Retrieval relevance is not proof that the source supports the research objective.",
                "The source's claims and methods require review before assigning a support status.",
            ],
        ) for idx, src in enumerate(sources)]


class MethodEvaluationEngine:
    """Return candidate methods, clearly labelled as preliminary suggestions."""
    def evaluate(self, objective: str) -> List[MethodEvaluation]:
        lower = (objective or "").lower()
        if any(term in lower for term in ("flood", "water", "runoff", "inundation")):
            return [MethodEvaluation(
                method_name="Candidate: hydrological / terrain-based flood modelling",
                purpose="Explore relationships between terrain, rainfall, and potential inundation.",
                required_inputs=["Suitable elevation data", "Rainfall data", "Study area", "Chosen model and boundary conditions"],
                expected_outputs=["Model-dependent inundation estimates", "Uncertainty and validation metrics"],
                limitations=["Preliminary candidate only; model choice and suitability are not yet verified.", "Requires suitable data, calibration, and validation."],
                compatibility_score="Unverified",
            )]
        if any(term in lower for term in ("building", "thermal", "insulation", "heat loss")):
            return [MethodEvaluation(
                method_name="Candidate: building thermal heat-transfer analysis",
                purpose="Estimate heat transfer through specified building materials and layers.",
                required_inputs=["Layer thickness", "Thermal conductivity", "Boundary temperatures", "Relevant surface conditions"],
                expected_outputs=["Calculated heat-transfer quantities under stated assumptions"],
                limitations=["Preliminary candidate only; steady-state assumptions may not fit the problem.", "Material data and boundary conditions must be supplied and checked."],
                compatibility_score="Unverified",
            )]
        return [MethodEvaluation(
            method_name="Candidate method selection (domain review required)",
            purpose="Identify a suitable analysis approach after clarifying the research question and evidence base.",
            required_inputs=["Defined objective", "Success criteria", "Relevant data and constraints"],
            expected_outputs=["Shortlisted methods with assumptions and validation requirements"],
            limitations=["No domain-specific method has been verified for this objective."],
            compatibility_score="Unverified",
        )]


class CalculationSimulationEngine:
    """Execute only registered, validated handlers."""

    def __init__(self):
        self.handlers = {"calculation_tool": self._run_lens_calculation}

    @staticmethod
    def _run_lens_calculation(inputs: Dict[str, Any]) -> Dict[str, Any]:
        try:
            f = float(inputs["focal_length_mm"])
            do = float(inputs["object_distance_mm"])
        except (KeyError, TypeError, ValueError):
            return {"status": "BLOCKED", "outputs": {}, "error": "focal_length_mm and object_distance_mm must be numeric inputs."}
        if f <= 0 or do <= 0:
            return {"status": "BLOCKED", "outputs": {}, "error": "Focal length and object distance must be positive."}
        if abs(do - f) < 1e-12:
            return {"status": "BLOCKED", "outputs": {}, "error": "Image distance is undefined for this thin-lens setup when object distance equals focal length."}
        di = (f * do) / (do - f)
        return {"status": "SUCCEEDED", "outputs": {"image_distance_mm": di, "magnification": -di / do}}

    def execute_task(self, capability_id: str, inputs: Dict[str, Any]) -> Dict[str, Any]:
        handler = self.handlers.get(capability_id)
        if handler is None:
            return {"status": "UNSUPPORTED", "outputs": {}, "error": f"Capability {capability_id} is not registered or available."}
        return handler(inputs or {})


class ResearchSimulationEngine:
    """Orchestrate discovery, evidence, candidate methods, and supported execution."""

    def __init__(self):
        self.discovery = ResearchDiscoveryEngine()
        self.evidence = EvidenceAnalysisEngine()
        self.methods = MethodEvaluationEngine()
        self.execution = CalculationSimulationEngine()

    def search_knowledge_base(self, query: str) -> List[ResearchSource]:
        return self.discovery.search(query)

    def process_action(
        self,
        action_type: str,
        objective: str,
        params: Optional[Dict[str, Any]] = None,
        project_id: str = "proj-default",
    ) -> Layer3Result:
        params = params or {}
        task_id = f"task-{int(time.time() * 1000)}"
        sources: List[ResearchSource] = []
        findings: List[EvidenceItem] = []
        methods: List[MethodEvaluation] = []
        exec_result: Dict[str, Any] = {
            "attempted": False, "capability_id": None, "status": "NOT_STARTED", "inputs": [], "outputs": []
        }
        blockers: List[str] = []
        limitations: List[str] = []
        uncertainties: List[str] = []
        status = "SUCCEEDED"
        summary = ""

        if action_type in {"RESEARCH", "IDENTIFY_METHODS", "EVALUATE_TOOLS", "ASSESS_FEASIBILITY"}:
            sources = self.discovery.search(objective)
            findings = self.evidence.analyze(sources, objective)
            if self.discovery.last_search_status == "FAILED":
                status = "FAILED"
                blockers.append(self.discovery.last_search_error or "Research provider failed.")
                summary = "Research discovery failed; no sources were fabricated."
            elif not sources:
                status = "NO_RESULTS"
                limitations.append(self.discovery.last_search_error or "No relevant sources were retrieved.")
                summary = "The search completed without relevant validated results."
            else:
                summary = f"Retrieved {len(sources)} source(s); source relevance is not equivalent to evidence support."
            if action_type in {"IDENTIFY_METHODS", "EVALUATE_TOOLS", "ASSESS_FEASIBILITY"}:
                methods = self.methods.evaluate(objective)
        elif action_type == "RUN_CALCULATION":
            res = self.execution.execute_task("calculation_tool", params)
            exec_result = {"attempted": True, "capability_id": "calculation_tool", "status": res["status"], "inputs": [params], "outputs": [res.get("outputs", {})], "error": res.get("error")}
            status = res["status"]
            summary = "Calculation completed." if status == "SUCCEEDED" else "Calculation could not be completed with the supplied inputs."
            if status != "SUCCEEDED": blockers.append(res.get("error", "Calculation blocked."))
        elif action_type == "RUN_SIMULATION":
            res = self.execution.execute_task("simulation_engine", params)
            exec_result = {"attempted": True, "capability_id": "simulation_engine", "status": res["status"], "inputs": [params], "outputs": [res.get("outputs", {})], "error": res.get("error")}
            status = res["status"]
            summary = "Simulation completed." if status == "SUCCEEDED" else "No simulation was run because no validated simulation handler is registered."
            if status != "SUCCEEDED": blockers.append(res.get("error", "Simulation capability is unavailable."))
        else:
            status = "UNSUPPORTED_ACTION"
            summary = f"Layer 3 does not implement action '{action_type}'."
            blockers.append("No registered handler exists for this action.")

        if status == "SUCCEEDED" and sources:
            uncertainties.append("Retrieved sources have not yet undergone full claim-level evidence review.")
        return Layer3Result(
            task_id=task_id,
            project_id=project_id,
            action_type=action_type,
            status=status,
            summary=summary,
            findings=findings,
            sources=sources,
            methods=methods,
            execution=exec_result,
            visualization_data={"available": False, "reason": "No scientific visualization payload was produced by this action."},
            limitations=limitations,
            uncertainties=uncertainties,
            blockers=blockers,
            recommended_next_actions=(
                ["Review retrieved sources", "Verify source claims before drawing conclusions"] if sources
                else ["Refine the research query", "Retry when the research provider is available"]
            ),
        )
